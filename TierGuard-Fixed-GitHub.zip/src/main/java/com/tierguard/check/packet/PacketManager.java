
package com.tierguard.check.packet;

import com.tierguard.util.AlertManager;
import org.bukkit.plugin.java.JavaPlugin;

public class PacketManager {
    public static void register(JavaPlugin plugin){
        plugin.getLogger().info("Packet system loaded");
    }
}
