
package com.tierguard;

import org.bukkit.plugin.java.JavaPlugin;

public class TierGuard extends JavaPlugin {
    @Override
    public void onEnable() {
        getLogger().info("TierGuard Enabled");
    }
}
