
package com.tierguard.util;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class AlertManager {
    public static void alert(String msg){
        Bukkit.getConsoleSender().sendMessage("[TierGuard] " + msg);
        for(Player p : Bukkit.getOnlinePlayers()){
            if(p.isOp()){
                p.sendMessage("§c[TierGuard] " + msg);
            }
        }
    }
}
