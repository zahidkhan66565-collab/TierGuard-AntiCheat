# TierGuard AntiCheat
Paper 1.21.11 PvP AntiCheat (Packet + Basic Checks)

Build:
mvn clean package
