
package com.tierguard.player;

import java.util.*;

public class PlayerManager {
    private final Map<UUID, PlayerData> map = new HashMap<>();

    public PlayerData get(UUID uuid){
        return map.computeIfAbsent(uuid, PlayerData::new);
    }
}
