
package com.tierguard.player;

import java.util.UUID;

public class PlayerData {
    public UUID uuid;
    public int vl;

    public PlayerData(UUID uuid){
        this.uuid = uuid;
    }

    public void addVL(){ vl++; }
}
