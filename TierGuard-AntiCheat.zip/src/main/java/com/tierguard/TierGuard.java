
package com.tierguard;

import org.bukkit.plugin.java.JavaPlugin;
import com.tierguard.check.packet.PacketManager;

public class TierGuard extends JavaPlugin {

    private static TierGuard instance;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        PacketManager.register(this);
        getLogger().info("TierGuard Enabled");
    }

    public static TierGuard getInstance() {
        return instance;
    }
}
