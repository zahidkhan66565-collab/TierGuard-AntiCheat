
package com.tierguard;

import org.bukkit.configuration.file.FileConfiguration;

public class TierConfig {
    private final FileConfiguration config;

    public TierConfig(TierGuard plugin){
        this.config = plugin.getConfig();
    }

    public double reach(){
        return config.getDouble("thresholds.reach");
    }
}
