
package com.tierguard.check.combat;

import com.tierguard.util.AlertManager;
import org.bukkit.entity.Player;
import org.bukkit.event.*;

public class ReachCheck implements Listener {

    @EventHandler
    public void hit(org.bukkit.event.entity.EntityDamageByEntityEvent e){

        if(!(e.getDamager() instanceof Player p)) return;
        if(!(e.getEntity() instanceof Player v)) return;

        double dist = p.getLocation().distance(v.getLocation());

        if(dist > 3.3){
            AlertManager.alert("Reach: " + p.getName());
        }
    }
}
