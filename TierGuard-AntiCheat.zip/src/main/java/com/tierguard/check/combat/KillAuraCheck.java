
package com.tierguard.check.combat;

import com.tierguard.util.AlertManager;
import org.bukkit.entity.Player;
import org.bukkit.event.*;

import java.util.*;

public class KillAuraCheck implements Listener {

    private final Map<UUID, Long> last = new HashMap<>();

    @EventHandler
    public void hit(org.bukkit.event.entity.EntityDamageByEntityEvent e){

        if(!(e.getDamager() instanceof Player p)) return;

        long now = System.currentTimeMillis();
        long lastHit = last.getOrDefault(p.getUniqueId(), 0L);

        if(now - lastHit < 40){
            AlertManager.alert("KillAura: " + p.getName());
        }

        last.put(p.getUniqueId(), now);
    }
}
