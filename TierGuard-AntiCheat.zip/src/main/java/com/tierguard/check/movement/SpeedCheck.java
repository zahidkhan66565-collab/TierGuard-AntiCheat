
package com.tierguard.check.movement;

import com.tierguard.util.AlertManager;
import org.bukkit.entity.Player;
import org.bukkit.event.*;

public class SpeedCheck implements Listener {

    @EventHandler
    public void move(org.bukkit.event.player.PlayerMoveEvent e){

        Player p = e.getPlayer();

        if(e.getFrom().distance(e.getTo()) > 0.75){
            AlertManager.alert("Speed: " + p.getName());
        }
    }
}
