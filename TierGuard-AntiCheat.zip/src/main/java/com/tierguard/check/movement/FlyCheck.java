
package com.tierguard.check.movement;

import com.tierguard.util.AlertManager;
import org.bukkit.entity.Player;
import org.bukkit.event.*;

public class FlyCheck implements Listener {

    @EventHandler
    public void move(org.bukkit.event.player.PlayerMoveEvent e){

        Player p = e.getPlayer();

        if(p.isGliding()) return;

        if(!p.isOnGround() && p.getFallDistance() == 0){
            AlertManager.alert("Fly: " + p.getName());
        }
    }
}
