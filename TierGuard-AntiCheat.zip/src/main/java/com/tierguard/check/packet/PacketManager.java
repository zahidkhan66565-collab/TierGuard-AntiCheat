
package com.tierguard.check.packet;

import com.comphenix.protocol.*;
import com.comphenix.protocol.events.*;
import com.tierguard.util.AlertManager;
import org.bukkit.plugin.java.JavaPlugin;

public class PacketManager {

    public static void register(JavaPlugin plugin){

        ProtocolLibrary.getProtocolManager().addPacketListener(
            new PacketAdapter(plugin, PacketType.Play.Client.POSITION) {

                @Override
                public void onPacketReceiving(PacketEvent event){
                    var p = event.getPlayer();
                    double y = event.getPacket().getDoubles().read(1);

                    if(!p.isOnGround() && y > p.getLocation().getY() + 1.2){
                        AlertManager.alert("Packet Fly: " + p.getName());
                    }
                }
            }
        );
    }
}
